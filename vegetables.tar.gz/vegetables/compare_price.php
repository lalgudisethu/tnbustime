<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>    
    <style>
        span:after {
            visibility: hidden;
        }
        form{
            background-color: coral;
            padding: 10px;
            position: absolute;
            left: 50%;
            top: 0%;
            transform: translateX(-50%);
            align-items: center;
        }
        input{
            margin-top: 10px;
            width: 100%;
        }
        h1{
            text-align: center;
        }
        a{
            text-decoration :none;
            background-color: crimson;
            cursor:pointer;
            padding: 10px;
            color: white;
            position: sticky;
            left: 0%;
            top: 0%;
        }
                footer {
            margin-top: 10px;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem 0;
            position: relative;
            width: 100%;
        }
    </style>
    
    
    
</head>
<body>
    <form action="" method="post">
        <label>SELECT DATE</label>
        <input type='date' name="dop" placeholder="Select Date"/>
        <input type="submit" VALUE = 'Fetch'/>
     </form> 
     <a href="index.html">HOME</a>
    <?php 

        if (isset($_POST['dop'])){
           
           $dop = $_POST['dop'];
           $prev_day = date('Y-m-d', strtotime('-1 days', strtotime($dop)));
           
            header("content-type: text/html; charset=UTF-8");  
            $dbname = "tnbustim_db";
            $conn = new mysqli("","tnbustim_admin","Sethu@123",$dbname);
            mysqli_set_charset($conn, "utf8");
            if ($conn->connect_error) 
            {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "select * from vegetables a,vegetables_data b where a.veg_id=b.veg_id and dop='$dop'";
            $sql1 = "select * from vegetables a,vegetables_data b where a.veg_id=b.veg_id and dop='$prev_day'";

            $result = $conn->query($sql);
            $result1 = $conn->query($sql1);

            $newdop = date("d/m/Y", strtotime($dop));
            if ($result->num_rows > 0) 
            {
                echo "<h1>Vegetable Price for Date ".$newdop."</h1>";
                echo "<table border='2' col width='100%'>";
                echo "<tr>";
                echo "<th>VEGETABLE</th>";
                echo "<th> இன்றைய விலை </th>";
                echo "<th> நேற்றைய விலை </th>";
                echo "<th> இன்றைய விலை </th>";
                echo "<th> நேற்றைய விலை </th>";
                echo "</tr>";
                while($row = $result->fetch_assoc()) 
                {
                    $row1 = $result1->fetch_assoc();
                ?>
                <tr>
                    <td style="width:30%;" ><?= $row['veg_name'] ?></td>
                    <td style="width:5%;" ><?= $row['price'] ?></td>
                    <td style="width:5%;" ><?= $row1['price'] ?></td>
                    <?php $val = $row['price']; $val1 = $row1['price'];  ?>
                    <td style="width:30%;"><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:blue; color:blue; display:inline-block; ">&nbsp;</span>
                    <td style="width:30%;"><span style="width: calc(100% - (100% - <?= $val1 ?>px)); background-color:green; color:blue; display:inline-block; ">&nbsp;</span>
                </tr>
                <?php            
                }
            }
            else{
                echo "<h1>NO DATA for Date ".$newdop."</h1>";
            }
        }
    ?>

</body>
</html>