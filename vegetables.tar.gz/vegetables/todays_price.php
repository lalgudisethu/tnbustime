<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>    
    <style>
        span:after {
            visibility: hidden;
        }
        form{
            background-color: coral;
            padding: 10px;
            position: absolute;
            left: 50%;
            top: 0%;
            transform: translateX(-50%);
            align-items: center;
        }
        input{
            margin-top: 10px;
            width: 100%;
        }
        h1{
            text-align: center;
        }
        a{
            text-decoration :none;
            background-color: crimson;
            cursor:pointer;
            padding: 10px;
            color: white;
            position: sticky;
            left: 0%;
            top: 0%;
        }
                footer {
            margin-top: 10px;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem 0;
            position: relative;
            width: 100%;
        }
    </style>
    
    
    
</head>
<body>
    <form action="" method="post">
        <label>SELECT DATE</label>
        <input type='date' name="dop" placeholder="Select Date"/>
        <input type="submit" VALUE = 'Fetch'/>
     </form> 
     <a href="index.html">HOME</a>
    <?php 
        $color = '';
        if (isset($_POST['dop'])){

            $dop = $_POST['dop'];

            $day = date('D', strtotime($dop));

            if ($day == 'Mon'){
                $color = 'yellow';
            }
            else if ($day == 'Tue'){
                $color = 'blue';
            }
            else if ($day == 'Wed'){
                $color = 'red';
            }
            else if ($day == 'Thu'){
                $color = 'green';
            }
            else if ($day == 'Fri'){
                $color = 'brown';
            }
            else if ($day == 'Sat'){
                $color = 'purple';
            }
            else if ($day == 'Sun'){
                $color = 'black';
            }

            header("content-type: text/html; charset=UTF-8");  
            $dbname = "tnbustim_db";
            $conn = new mysqli("","tnbustim_admin","Sethu@123",$dbname);
            mysqli_set_charset($conn, "utf8");
            if ($conn->connect_error) 
            {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "select * from vegetables a,vegetables_data b where a.veg_id=b.veg_id and dop='$dop'";
            //$sql = "SELECT b.veg_name as veg_name,round(AVG(a.price)) as price FROM vegetables_data a,vegetables b where a.veg_id = b.veg_id GROUP by a.veg_id order by a.price desc";
            $result = $conn->query($sql);
            $newdop = date("d/m/Y", strtotime($dop));
            if ($result->num_rows > 0) 
            {
                echo "<h1>Vegetable Price for Date ".$newdop."</h1>";
                echo "<table border='2' col width='100%'>";
                echo "<tr>";
                echo "<th>VEGETABLE</th>";
                echo "<th>PRICE</th>";
                echo "<th>VALUE</th>";
                echo "</tr>";
                while($row = $result->fetch_assoc()) 
                {
                ?>
                <tr>
                    <td style="width:30%;" ><?= $row['veg_name'] ?></td>
                    <td style="width:20%;" ><?= $row['price'] ?></td>
                    <?php $val = $row['price']; ?>
                    <?php if ($day == "Mon" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:hotpink; display:inline-block; ">&nbsp;</span>
                    <?php } else if ($day == "Tue" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:blue;  display:inline-block; ">&nbsp;</span>
                    <?php } else if ($day == "Wed" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:red;  display:inline-block; ">&nbsp;</span>                    
                    <?php } else if ($day == "Thu" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:green; display:inline-block; ">&nbsp;</span>                    
                    <?php } else if ($day == "Fri" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:orange; display:inline-block; ">&nbsp;</span>                    
                    <?php } else if ($day == "Sat" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:purple; display:inline-block; ">&nbsp;</span>                    
                    <?php } else if ($day == "Sun" ) { ?>
                        <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:black; display:inline-block; ">&nbsp;</span>                    
                    <?php } ?>
                </tr>
                <?php            
                }
            }
            else{
                echo "<h1>NO DATA for Date ".$newdop."</h1>";
            }
        }
    ?>

</body>
</html>