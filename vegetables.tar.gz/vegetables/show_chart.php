<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>    
    <style>
        span:after {
            visibility: hidden;
        }
        form{
            background-color: coral;
            padding: 10px;
            position: absolute;
            left: 50%;
            top: 0%;
            transform: translateX(-50%);
        }
        a{
            text-decoration :none;
            background-color: crimson;
            cursor:pointer;
            padding: 10px;
            color: white;
            position: sticky;
            left: 0%;
            top: 0%;
        }
        h3{
            text-align: center;
        }
        footer {
/*            position: absolute;
            bottom: 0px;
            width: 100%;
            background-color: #333;
            color: white;
            text-align: center;*/
           margin-top: 10px;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem 0;
            position: relative;
            width: 100%;
        }
    </style>
    
    
    
</head>
<body>
    <a href="index.html">HOME</a>
<!--    <form action="" method="post">
        <input type='date' name="dop"/>
        <input type="submit" VALUE = 'Fetch'/>
    </form> -->
    <?php 
        #if (isset($_POST['dop'])){

         #   $dop = $_POST['dop'];

            header("content-type: text/html; charset=UTF-8");  
            $dbname = "tnbustim_db";
            $conn = new mysqli("","tnbustim_admin","Sethu@123",$dbname);
            mysqli_set_charset($conn, "utf8");
            if ($conn->connect_error) 
            {
                die("Connection failed: " . $conn->connect_error);
            }
            #$sql = "select * from vegetables a,vegetables_data b where a.veg_id=b.veg_id and dop='$dop'";
            $sql = "SELECT b.veg_name as veg_name,round(AVG(a.price)) as price FROM vegetables_data a,vegetables b where b.veg_id = a.veg_id GROUP by a.veg_id order by a.price DESC";
            $result = $conn->query($sql);
            echo "<h3>AVERAGE PRICE IN THE PAST FEW DAYS</h3>";
            echo "<table border='2' width='100%'>";
            echo "<tr>";
            echo "<th>VEGETABLE</th>";
            echo "<th>PRICE</th>";
            echo "<th>VALUE</th>";
            echo "</tr>";
            if ($result->num_rows > 0) 
            {
            while($row = $result->fetch_assoc()) 
            {
            ?>
            <tr>
                <td style="width:30%"; ><?= $row['veg_name'] ?></td>
                <td style="width:20%";><?= $row['price'] ?></td>
                <?php $val = $row['price']; ?>
                <td><span style="width: calc(100% - (100% - <?= $val ?>px)); background-color:blue; color:blue; display:inline-block; ">&nbsp;</span>
            </tr>
            <?php            
            }
            }
        #}
    ?>
        <footer>
            <h4>CONTACT FOR SOFTWARE SOLUTIONS and COMPUTER CLASSES</h4>
            <b>DEVELOPED AND MAINTAINED BY SETHU J (9865863825)</b>
        </footer>
</body>
</html>