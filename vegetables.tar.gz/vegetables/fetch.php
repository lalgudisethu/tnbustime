<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>    
</head>
<body>
    <?php 
        header("content-type: text/html; charset=UTF-8");  
        $dbname = "tnbustim_db";
        $conn = new mysqli("","tnbustim_admin","Sethu@123",$dbname);
        mysqli_set_charset($conn, "utf8");
        if ($conn->connect_error) 
        {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "select * from vegetables";
    ?>
    <div>
        <h1>காய்கறிகள்</h1>
        <select id='vegetable'>
        <option value="-1">Select</option>
    <?php
        $result = $conn->query($sql);
        if ($result->num_rows > 0) 
        {
          while($row = $result->fetch_assoc()) 
          {
    ?>
        <option value="<?=$row['veg_id']?>"><?= $row['veg_name'] ?></option>   
    <?php 
          }
    }
    ?>
        </select>
        <div>
            <label for="dop">Select the Date</label>
            <input type="date" name='dop' id='dop'>
        </div>
        <div>
            <button onclick="fetchData()">Submit</button>
        </div>
        <div id='result'>
            
        </div>
    </div>
    <script>
        function fetchData(){
            var veg_id = $('#vegetable').val();
            var dop = $('#dop').val();
            $.ajax({
                url: 'get.php',
                type: 'POST',
                data: {veg_id:veg_id,dop:dop},
                success: function(response){
                    $("#result").html(response);
                }
            });
        }
    </script>
</body>
</html>