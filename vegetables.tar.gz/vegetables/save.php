<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>    
</head>
<body>
    <?php 
        header("content-type: text/html; charset=UTF-8");  
        $dbname = "tnbustim_db";
        $conn = new mysqli("","tnbustim_admin","Sethu@123",$dbname);
        $veg_id = $_POST['veg_id'];
        $dop = $_POST['dop'];
        $price = $_POST['price'];
        mysqli_set_charset($conn, "utf8");
        if ($conn->connect_error) 
        {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "insert into vegetables_data values($veg_id,'$dop',$price)";
        $res = $conn->execute_query($sql);
        if ($res){
            echo "Success";
        }
        else{
            echo "Failure";
        }
    ?>
</body>
</html>