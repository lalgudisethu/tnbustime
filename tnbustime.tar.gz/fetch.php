
<html>
<head>
    <style type="text/css">
        *{
            text-align: center;
        }
        h4{
            background-color: blue;
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align:center;
            box-shadow: 5px 10px #888888;
        }
        button
        {
            padding: 0.75rem 1.5rem;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 2rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
    </style>
</head>
<body>
<?php
    header("content-type: text/html; charset=UTF-8");  
    $dbname = "tnbustim_db";
    $from_place = $_POST['from_place'];
    $to_place = $_POST['to_place'];
    $pri_pub = $_POST['private_public'];
    $ac_one = $_POST['ac_one'];
    $main = $stop1 = $stop2 = 0;

    $conn = new mysqli("localhost","tnbustim_admin","Sethu@123",$dbname);
    mysqli_set_charset($conn, "utf8");
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($pri_pub == 'PUBLIC')
    {
        $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and service_name = 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name = 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name = 'அரசு GOVT' order by st_time";        
        $main = 1;
    }
    else if ($pri_pub == 'PRIVATE')
    {
        $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and service_name != 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name != 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name != 'அரசு GOVT' order by st_time";       
        $main = 1;
    }
    else
    {
        $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' OR  from_place='$from_place' AND stop1='$to_place' OR from_place='$from_place' AND stop2='$to_place' order by st_time";        
        $main = 1;
    }

    if ($ac_one == 'AC' and $pri_pub == null)
    {
        $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR  from_place='$from_place' AND stop1='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR from_place='$from_place' AND stop2='$to_place' and special = 'A / C  குளிர்சாதன வசதி' order by st_time";        
        $main = 1;
    }
    else if ($ac_one == 'ONE' and $pri_pub == null)
    {
        $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and special = '1 TO 1' OR  from_place='$from_place' AND stop1='$to_place' and special = '1 TO 1' OR from_place='$from_place' AND stop2='$to_place' and special = '1 TO 1' order by st_time";        
        $main = 1;
    }


    $result = $conn->query($sql);
    
    echo "<strong> கொடுக்கப்பட்டுள்ள நேரத்திற்கு 5 அல்லது 10 நிமிடம் முன்னதாக பஸ் ஸ்டாண்ட் செல்லவும் </strong> <br><br>";

    if ($result->num_rows > 0) 
    {
          while($row = $result->fetch_assoc()) 
          {
            echo "<h4> Bus Service <string>".$row['service_name']."</strong> <br>";
            echo $row["from_place"]. " புறப்படும் நேரம்: ".$row["start_time"]."<br>".$row["to_place"]." சேரும் நேரம் : ".$row["reach_time"]."<br> வழி: <br>";
            echo  $row["stop1"]." ".$row["stop1_time"]."<br>";
            echo  $row["stop2"]." ".$row["stop2_time"]."<br> ".$row['special']." </h4>";
        }
    }

            if ($pri_pub == 'PUBLIC')
            {
                $sql = "select * from bus_routes where stop1='$from_place' AND to_place='$to_place' and service_name = 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name = 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name = 'அரசு GOVT'";        
            }
            else if ($pri_pub == 'PRIVATE')
            {
                $sql = "select * from bus_routes where stop1='$from_place' AND to_place='$to_place' and service_name != 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name != 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name != 'அரசு GOVT'";       
            }
            else
            {
                #$sql = "select * from bus_routes where stop1='$from_place' AND to_place='$to_place' OR  from_place='$from_place' AND stop1='$to_place' OR from_place='$from_place' AND stop2='$to_place' order by st_time";        
                $sql = "select * from bus_routes where stop1='$from_place' AND to_place='$to_place' OR  stop1='$from_place' AND stop2='$to_place' order by st_time";        
            }
            if ($ac_one == 'AC' and $pri_pub == null)
            {
                $sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR  from_place='$from_place' AND stop1='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR from_place='$from_place' AND stop2='$to_place' and special = 'A / C  குளிர்சாதன வசதி'";        
            }
            else if ($ac_one == 'ONE' and $pri_pub == null)
            {
                #$sql = "select * from bus_routes where from_place='$from_place' AND to_place='$to_place' and special = '1 TO 1' OR  from_place='$from_place' AND stop1='$to_place' and special = '1 TO 1' OR from_place='$from_place' AND stop2='$to_place' and special = '1 TO 1'";        
                $sql = "select * from bus_routes where stop1='$from_place' AND to_place='$to_place' OR  stop1='$from_place' AND stop2='$to_place' order by st_time";        
            }
            $result = $conn->query($sql);
            if ($result->num_rows > 0) 
            {
                while($row = $result->fetch_assoc()) 
                {
                echo "<h4> Bus Service <string>".$row['service_name']."</strong> <br>";
                echo $row["from_place"]. " புறப்படும் நேரம்: ".$row["start_time"]."<br>".$row["to_place"]." சேரும் நேரம் : ".$row["reach_time"]."<br> வழி: <br>";
                echo  $row["stop1"]." ".$row["stop1_time"]."<br>";
                echo  $row["stop2"]." ".$row["stop2_time"]."<br> ".$row['special']." </h4>";
                }
            }
            if ($pri_pub == 'PUBLIC')
                   {
                        $sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' and service_name = 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name = 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name = 'அரசு GOVT'";        
                  }
                  else if ($pri_pub == 'PRIVATE')
                  {
                    $sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' and service_name != 'அரசு GOVT' OR  from_place='$from_place' AND stop1='$to_place' and service_name != 'அரசு GOVT' OR from_place='$from_place' AND stop2='$to_place' and service_name != 'அரசு GOVT'";       
                  }
                  else
                    {
                        #$sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' OR  from_place='$from_place' AND stop1='$to_place' OR from_place='$from_place' AND stop2='$to_place' order by st_time";        
                        $sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' order by st_time";        
                    }
                    if ($ac_one == 'AC' and $pri_pub == null)
                    {
                        $sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR  from_place='$from_place' AND stop1='$to_place' and special = 'A / C  குளிர்சாதன வசதி' OR from_place='$from_place' AND stop2='$to_place' and special = 'A / C  குளிர்சாதன வசதி'";        
                    }
                    else if ($ac_one == 'ONE' and $pri_pub == null)
                    {
                        $sql = "select * from bus_routes where stop2='$from_place' AND to_place='$to_place' and special = '1 TO 1' OR  from_place='$from_place' AND stop1='$to_place' and special = '1 TO 1' OR from_place='$from_place' AND stop2='$to_place' and special = '1 TO 1'";        
                    }
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) 
                    {
                        while($row = $result->fetch_assoc()) 
                        {
                            echo "<h4> Bus Service <string>".$row['service_name']."</strong> <br>";
                            echo $row["from_place"]. " புறப்படும் நேரம்: ".$row["start_time"]."<br>".$row["to_place"]." சேரும் நேரம் : ".$row["reach_time"]."<br> வழி: <br>";
                            echo  $row["stop1"]." ".$row["stop1_time"]."<br>";
                            echo  $row["stop2"]." ".$row["stop2_time"]."<br> ".$row['special']." </h4>";
                        }
                    }
                    else{
                        echo "<h2> No Service </h2>";                    
                    }

    echo "<strong> கொடுக்கப்பட்டுள்ள நேரத்திற்கு 5 அல்லது 10 நிமிடம் முன்னதாக பஸ் ஸ்டாண்ட் செல்லவும் </strong> <br><br>";
    echo "<button onclick=homePage()>HOME</button>";
    $conn->close();
?>
<script>
       function homePage()
        {
                window.location = '/';   
        }
</script>

</body>
</html>