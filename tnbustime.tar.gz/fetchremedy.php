
<html>
<head>
    <style type="text/css">
        *{
            text-align: center;
        }
        h4{
            background-color: blue;
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align:center;
            box-shadow: 5px 10px #888888;
        }
        button
        {
            padding: 0.75rem 1.5rem;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 2rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
    </style>
</head>
<body>
<?php
    header("content-type: text/html; charset=UTF-8");  
    $dbname = "tnbustim_db";
    $id = $_POST['id'];

    $conn = new mysqli("localhost","tnbustim_admin","Sethu@123",$dbname);
    mysqli_set_charset($conn, "utf8");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    
       
    $sql = "select prob_id,solution from remedy where prob_id=$id";        
   
    
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc(); 
        $res = $row['solution'];
        echo "<h2> $res </h2>";
    }
    $conn->close();
?>
<script>
       function homePage()
        {
                window.location = '/';   
        }
</script>

</body>
</html>